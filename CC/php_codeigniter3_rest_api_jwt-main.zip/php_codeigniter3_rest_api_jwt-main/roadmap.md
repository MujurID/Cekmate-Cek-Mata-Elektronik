 # Roadmap

 - [x] Create a helper to verify token/logged user
 - [x] Validate input data with form validation
    - [X] Products
    - [x] User
 - [X] API REST URLs refactor
 - [x] Put status in every return message // Correct HTTP response codes
 - [x] simplify database
 - [x] change token param to CamelCase
 - [x] refresh readme.md with new URLs // review readme.md
 - [x] put reference https://github.com/chriskacerguis/codeigniter-restserver
 - [x] put verify token on readme.md
 - [x] go live on dreamhost
 - [x] move projects to portfolio
 - [x] update readme.md with instructions to access the sandbox live on vittoretti.com
 - [ ] renew token?
 